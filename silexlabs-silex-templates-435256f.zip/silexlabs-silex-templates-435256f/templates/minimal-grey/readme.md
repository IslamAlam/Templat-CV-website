#Minimal grey Silex template

##What is this?

This is a free template for [Silex, live web creation](http://www.silex.me), the HTML editor and website builder for designers.

##How to customize it for your website?

Download the [zip file on github](https://github.com/silexlabs/silex-templates) and unzip to a folder in your dropbox. Then [open Silex in a browser](http://www.silex.me/silex) and open the template file "editable.html".

Then insert your content, modify the design and use it for your website.

##How to contribute

These pages are made without programming, just drag and drop, with [Silex, live web creation](http://www.silex.me/). So feel free to fork this github repository, make changes and make a pull request.

Silex template by lexoyo is licensed under a Creative Commons Attribution 3.0 Unported License.

##Other Silex templates

* [about me page](https://github.com/lexoyo/lexoyo.github.io)

